"use client"

export default function HeaderDashboard() {

    return (
        <div className="layoutDashboard h-28 p-4 flex items-center border-bottom border-[#1F4D36] border-opacity-30 border-b-2">
            <h1 className="text-xl mx-5">Olá,  seja bem vindo(a) ao Providenzz!</h1>        
        </div>
    )
}